<!DOCTYPE html>
<html>
    <head>
        <title>PHP Starter Application - Alterado</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="stylesheet" href="style.css" />
    </head>
    <body>
        <table>
            <tr>
                <td style='width: 30%;'><img class = 'newappIcon' src='images/newapp-icon.png'>
                </td>
                <td>
                    <h1 id = "message"><?php echo "Hello world! vai capeta!"; ?>
                    </h1>
                    <p class='description'></p> Thanks for creating a <span class="blue">PHP Starter Application</span>. To get started see the Start Coding guide under your app in your dashboard.
                </td>
            </tr>
        </table>
    </body>
</html>

<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
ini_set('xdebug.var_display_max_depth', -1);
ini_set('xdebug.var_display_max_children', -1);
ini_set('xdebug.var_display_max_data', -1);

//echo phpinfo();
//exit;
//$conect = mysql_connect('us-cdbr-iron-east-04.cleardb.net', 'bcfbd78be73001', '335ab6b6');

$host = "jumbo.db.elephantsql.com";
$user = "mfseibzi";
$pass = "UDXaj-X2gYgoWiOlHbO_UadCMW5UQ-nr";
$db = "mfseibzi";
$con = pg_connect("host=$host dbname=$db user=$user password=$pass");

//$conect = mysql_connect("localhost", "root", "123");

if ($con) {
    echo "Conexao ok";
} else {
    echo "Cara, não rolou não";
}