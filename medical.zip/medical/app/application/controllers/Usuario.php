<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {

    public function index() {
        $this->load->view('login_view');
    }

    public function login() {
        try {
            $this->load->model("usuario_model");
            $usuarios = $this->usuario_model->getUsuarioEnfermeiraLogin($this->input->post("email"), $this->input->post("senha"));
            if (count($usuarios) > 0) {
                $this->session->set_userdata("id_usuario", $usuarios[0]->id);
                $this->session->set_userdata("nome_usuario", $usuarios[0]->nome);

                /*
                 * REDIRECT
                 */
                redirect(base_url() . "dashboard");
            } else {
                $this->session->set_flashdata('msg', "E-Mail e/ou senha não confere");
                $this->session->set_flashdata('type', 'warning');
                $this->session->set_flashdata('title', 'Acesso restrito');

                redirect(base_url() . "autenticacao");
            }
        } catch (Exception $ex) {
            var_dump($ex);
        }
    }
    
    public function logout(){
        redirect(base_url() . "autenticacao");
    }

}
