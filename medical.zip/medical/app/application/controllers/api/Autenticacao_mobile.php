<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Autenticacao_mobile extends CI_Controller {

    public function index() {
        echo "Index";
    }

    public function login() {
        try {
            $this->load->model("usuario_model");
            $usuarios = $this->usuario_model->getUsuarioMedicoLogin($this->input->post("email"), $this->input->post("senha"));
            if (count($usuarios) > 0) {
                $resposta = array("sucesso" => 'true', "mensagem" => "Login realizado com sucesso!", "usuario" => $usuarios[0]->id);
            } else {
                $resposta = array("sucesso" => 'false', "mensagem" => "Usuário ou senha incorretos!");
            }
            echo json_encode($resposta);
        } catch (Exception $ex) {
            var_dump($ex);
        }
    }

}
