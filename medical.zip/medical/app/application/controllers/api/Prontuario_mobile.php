<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Prontuario_mobile extends CI_Controller {

    public function index() {
        echo "Index";
    }

    public function listar($idMedico) {
        try {
            $this->load->model("prontuario_model");
            $prontuarios = $this->prontuario_model->listProntuariosMedico($idMedico);

            if (count($prontuarios) > 0) {
                $resposta = array("sucesso" => 'true', "mensagem" => "", "prontuarios" => $prontuarios);
            } else {
                $resposta = array("sucesso" => 'true', "mensagem" => "", "prontuarios" => array());
            }

            echo json_encode($resposta);
        } catch (Exception $ex) {
            var_dump($ex);
        }
    }

    public function getProntuario($idProntuario) {
        try {
            $this->load->model("prontuario_model");
            $prontuario = $this->prontuario_model->getProntuario($idProntuario);
            if (count($prontuario) > 0){
                $prontuario = $prontuario;
                $this->load->model("sensor_model");
                $sensores = $this->sensor_model->getUltimosDados($idProntuario);
                $resposta = array("sucesso" => 'true', "mensagem" => "", "prontuario" => $prontuario, "sensores" => $sensores);
                //$resposta = array("sucesso" => 'true', "mensagem" => "", "prontuario" => $prontuario);
                echo json_encode($resposta);
            } else {
                $resposta = array("sucesso" => 'false', "mensagem" => "Prontuário não encontrado");
                echo json_encode($resposta);
            }
        } catch (Exception $ex) {
            var_dump($ex);
        }
    }

}
