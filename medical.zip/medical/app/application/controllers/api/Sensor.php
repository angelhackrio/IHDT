<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Sensor extends CI_Controller {

    public function index() {
        echo "Index";
    }

    public function set() {
        try {
            $this->load->model("equipamento_model");
            $this->load->model("sensor_model");
            $this->load->model("prontuario_model");

            $equipamentos = $this->equipamento_model->getEquipamento($this->input->post("key"));

            if (count($equipamentos) > 0) {

                $prontuarios = $this->prontuario_model->getProntuario($this->input->post("id_prontuario"));

                if (count($prontuarios) > 0) {
                    if (!($prontuarios[0]->alta === 't' || $prontuarios[0]->dispensado === 't')) {
                        /**
                         * 1 = Convulsao
                         * 2 = Hipertemia
                         * 3 = Vomito
                         * 4 = Hipotermia
                         */
                        //$this->sensor_model->setDados(array("temperatura" => $this->input->post("temperatura"), "umidade" => $this->input->post("umidade"), "temperatura_externa" => $this->input->post("temperatura_externa"), "umidade_externa" => $this->input->post("umidade_externa"), "id_prontuario" => $this->input->post("id_prontuario"), "id_equipamento" => $equipamentos[0]->id));
                        $this->sensor_model->setDados(array("temperatura" => $this->input->post("temperatura"), "umidade" => $this->input->post("umidade"), "temperatura_externa" => $this->input->post("temperatura_externa"), "umidade_externa" => $this->input->post("umidade_externa"), "id_prontuario" => $this->input->post("id_prontuario"), "id_equipamento" => $equipamentos[0]->id, "acelerometro_x" => $this->input->post("acelerometro_x"), "acelerometro_y" => $this->input->post("acelerometro_y"), "acelerometro_z" => $this->input->post("acelerometro_z")));
                        $this->load->model("ocorrencia_model");
                        if ($this->input->post("temperatura") > 26){
                            $this->ocorrencia_model->setOcorrencia($this->input->post("id_prontuario"), 2);
                            redirect("http://servicos.mybluemix.net/envia_sms?msg=Febre alta detectada em paciente&numero=+5519982249772");
                            
                        } else if ($this->input->post("temperatura") < 10) {
                            $this->ocorrencia_model->setOcorrencia($this->input->post("id_prontuario"), 4);
                        } else if ($this->input->post("umidade") > 60) {
                            $this->ocorrencia_model->setOcorrencia($this->input->post("id_prontuario"), 3);
                        } 
                        
                        $resposta = array("sucesso" => 'true', "mensagem" => "Dados registrados com sucesso!");
                        echo json_encode($resposta);
                    } else {
                        $resposta = array("sucesso" => 'false', "mensagem" => "Paciente já está de alta ou já foi dispensado");
                        echo json_encode($resposta);
                    }
                } else {
                    $resposta = array("sucesso" => 'false', "mensagem" => "Prontuario inexistente");
                    echo json_encode($resposta);
                }
            } else {
                $resposta = array("sucesso" => 'false', "mensagem" => "Equipamento não autorizado");
                echo json_encode($resposta);
            }
        } catch (Exception $ex) {
            var_dump($ex);
        }
    }

//    public function get($idProntuario) {
//        try {
//            $this->load->model("sensor_model");
//            $sensors = $this->sensor_model->getUltimosDados($idProntuario);
//
//            if (count($sensors) > 0) {
//                $resposta = array("sucesso" => 'true', "mensagem" => "", "sensor" => $sensors[0]);
//            } else {
//                $resposta = array("sucesso" => 'true', "mensagem" => "", "sensor" => array());
//            }
//
//            echo json_encode($resposta);
//        } catch (Exception $ex) {
//            var_dump($ex);
//        }
//    }

}
