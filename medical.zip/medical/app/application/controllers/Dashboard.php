<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function index() {
        $data['pagina'] = 'dashboard';
        $this->load->view('cabecalho', $data);
        $this->load->view('dashboard_view');
        $this->load->view('rodape');
    }

    public function atualizarDashboard() {
        try {
            $this->load->model("prontuario_model");
            $prontuarios = $this->prontuario_model->listProntuariosDashboard();

            foreach ($prontuarios as $prontuario) {
                $prontuario->datahora = date('d/m/Y H:i:s', strtotime($prontuario->datahora));
                $prontuario->data_nascimento = date('d/m/Y', strtotime($prontuario->data_nascimento));
            }

            $resposta = array("sucesso" => 'true', "mensagem" => "", "prontuarios" => $prontuarios);
            echo json_encode($resposta);
        } catch (Exception $ex) {
            $resposta = array("sucesso" => 'false', "mensagem" => "Erro");
            echo json_encode($resposta);
        }
    }

    public function resolver($idOcorrencia) {
        try {
            
            $this->load->model("ocorrencia_model");
            $this->ocorrencia_model->resolver($idOcorrencia);

            redirect(base_url() . "dashboard");
        } catch (Exception $ex) {
            redirect(base_url() . "dashboard");
        }
    }

}
