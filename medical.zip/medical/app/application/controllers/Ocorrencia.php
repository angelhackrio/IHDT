<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ocorrencia extends CI_Controller {

    public function index() {
        redirect(base_url() . "dashboard");
    }

    public function resolver($idOcorrencia) {
        try {

            $this->load->model("ocorrencia_model");
            $this->ocorrencia_model->resolver($idOcorrencia);

            redirect(base_url() . "dashboard");
        } catch (Exception $ex) {
            redirect(base_url() . "dashboard");
        }
    }

}
