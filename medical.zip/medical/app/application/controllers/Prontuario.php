<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Prontuario extends CI_Controller {

    public function index() {
        echo "index";
    }

    public function ver($idProntuario) {
        try {
            $this->load->model("prontuario_model");
            $prontuarios = $this->prontuario_model->getProntuario($idProntuario);

            if (count($prontuarios) > 0) {
                $prontuarios = $prontuarios[0];

                $data['pagina'] = 'prontuario';
                $data['prontuario'] = $prontuarios;
                $this->load->view('cabecalho', $data);
                $this->load->view('prontuario_view');
                $this->load->view('rodape');
            } else {
                $this->session->set_flashdata('msg', "Prontuário inexistente");
                $this->session->set_flashdata('type', 'warning');
                $this->session->set_flashdata('title', 'Prontuario');

                redirect(base_url() . "dashboard");
            }
        } catch (Exception $ex) {
            var_dump($ex);
        }
    }

    public function dadosGraficos($idProntuario) {
        $this->load->model("sensor_model");
        $dados = $this->sensor_model->getUltimosDados($idProntuario);
        foreach($dados as $dado){
            $dado->dataFormatada = date('d/m/Y H:i:s', strtotime($dado->datahora));
        }
        $resposta = array("sucesso" => 'true', "mensagem" => "", "dados" => $dados);
        echo json_encode($resposta);
    }

}
