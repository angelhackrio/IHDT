</body>
<footer>
    <script>
        base_url = '<?php echo base_url(); ?>';
    </script>
    <script type="text/javascript" src="<?php echo base_url('public/js/plugins/jquery-2.1.4.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('public/js/bootstrap/bootstrap.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('public/js/plugins/zebra_dialog/zebra_dialog.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('public/js/plugins/canvasjs.min.js') ?>"></script>
    <?php if ($pagina === 'dashboard') { ?>
        <script type="text/javascript" src="<?php echo base_url('public/js/paginas/dashboard.js') ?>"></script>
    <?php } ?>
    <?php if ($pagina === 'prontuario') { ?>
        <script type="text/javascript" src="<?php echo base_url('public/js/paginas/prontuario.js') ?>"></script>
    <?php } ?>
    <script type="text/javascript" src="<?php echo base_url('public/js/plugins/zebra_dialog/zebra_dialog.js') ?>"></script>
    <script>
        var msg = "<?php echo $this->session->flashdata('msg'); ?>";
        var type = "<?php echo $this->session->flashdata('type'); ?>";
        var title = "<?php echo $this->session->flashdata('title'); ?>";
        if (msg !== "") {
            $.Zebra_Dialog(msg, {'title': title, 'type': type});
        }
    </script>
</footer>
</html>