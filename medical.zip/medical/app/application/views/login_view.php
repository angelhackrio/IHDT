<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Medical</title>
        <meta name="description" content="Medical">
        <meta name="author" content="FATEC">

        <!-- Mobile Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo base_url('public/img/favicon.ico') ?>">

        <!-- Bootstrap core CSS -->
        <link href="<?php echo base_url('public/css/bootstrap/bootstrap.css') ?>" rel="stylesheet">

        <!-- Font Awesome CSS -->
        <link href="<?php echo base_url('public/fonts/font-awesome/css/font-awesome.css') ?>" rel="stylesheet">

        <!-- Custom css --> 
        <link href="<?php echo base_url('public/css/custom.css" rel="stylesheet') ?>">

        <!-- Zebra css --> 
        <link href="<?php echo base_url('public/css/zebra_dialog/flat/zebra_dialog.css" rel="stylesheet') ?>">
    </head>
    <body>
        <div class="col-md-4 col-md-offset-4">
            <p class="text-center logo">
                <!--<img src="<?php echo base_url('public/img/logo.png'); ?>" />-->
            </p>            
        </div>
        <div class="col-md-4 col-md-offset-4">
            <form action="<?php echo base_url("usuario/login"); ?>" method="POST">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <i class="fa fa-sign-in text-info"></i> <span>Login</span>
                        </div>
                    </div>
                    <div class="panel-body">                    
                        <div class="form-group col-md-12">
                            <i class="fa fa-envelope text-info"></i> Usuário:
                            <input class="form-control" type="text" name="email" placeholder="usuário" />
                        </div>
                        <div class="form-group col-md-12">
                            <i class="fa fa-key text-info"></i> Senha:
                            <input class="form-control" type="password" name="senha" placeholder="senha" />
                        </div>
                    </div>
                    <div class="panel-footer">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-info pull-right"><i class="fa fa-sign-in"></i> Login</button>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </form>
        </div>
    </body>
    <footer>
        <script type="text/javascript" src="<?php echo base_url('public/js/plugins/jquery-2.1.4.min.js') ?>"></script>
        <script type="text/javascript" src="<?php echo base_url('public/js/bootstrap/bootstrap.min.js') ?>"></script>
        <script type="text/javascript" src="<?php echo base_url('public/js/plugins/zebra_dialog/zebra_dialog.js') ?>"></script>
        <script>
            var msg = "<?php echo $this->session->flashdata('msg'); ?>";
            var type = "<?php echo $this->session->flashdata('type'); ?>";
            var title = "<?php echo $this->session->flashdata('title'); ?>";
            if (msg !== "") {
                $.Zebra_Dialog(msg, {'title': title, 'type': type});
            }
        </script>
    </footer>
</html>