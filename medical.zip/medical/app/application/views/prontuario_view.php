<input type="hidden" id="hdId" value="<?php echo $prontuario->id; ?>" />
<div class="col-md-12">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Temperatura</h3>
            </div>
            <div class="panel-body">
                <strong>Nome:</strong> <?php echo $prontuario->nome . " " . $prontuario->sobrenome; ?><br />
                <strong>Data de nascimento:</strong> <?php echo $prontuario->data_nascimento; ?><br />
                <strong>Data de internação:</strong> <?php echo $prontuario->datahora; ?><br />
            </div>
        </div>        
    </div>
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Temperatura</h3>
            </div>
            <div id="graficoTemperatura" style="height: 500px; width: 100%;"></div>
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Umidade</h3>
            </div>
            <div id="graficoUmidade" style="height: 500px; width: 100%;"></div>
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Acelerometro</h3>
            </div>
            <div id="graficoAcelerometro" style="height: 500px; width: 100%;"></div>
        </div>
    </div>