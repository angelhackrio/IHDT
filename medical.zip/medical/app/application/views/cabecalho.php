<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Medical</title>
        <meta name="description" content="Medical">
        <meta name="author" content="FATEC">

        <!-- Mobile Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo base_url('public/img/favicon.ico') ?>">

        <!-- Bootstrap core CSS -->
        <link href="<?php echo base_url('public/css/bootstrap/bootstrap.css') ?>" rel="stylesheet">

        <!-- Font Awesome CSS -->
        <link href="<?php echo base_url('public/fonts/font-awesome/css/font-awesome.css') ?>" rel="stylesheet">

        <!-- Custom css --> 
        <link href="<?php echo base_url('public/css/custom.css" rel="stylesheet') ?>">

        <!-- Zebra css --> 
        <link href="<?php echo base_url('public/css/zebra_dialog/flat/zebra_dialog.css" rel="stylesheet') ?>">
    </head>
    <body>
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Medical</a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li class="<?php echo $pagina === 'dashboard' ? 'active' : ''; ?>"><a href="<?php echo base_url('dashboard'); ?>">Dashboard</a></li>                        
                        <!--<li class="<?php echo $pagina === 'pacientes' ? 'active' : ''; ?>"><a href="<?php echo base_url('pacientes'); ?>">Pacientes</a></li>-->
                    </ul> 
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="<?php echo base_url('usuario/logout'); ?>">Sair</a></li>
                        <li><a href="javasript:void(0);">Olá <?php echo $this->session->userdata("nome_usuario"); ?></a></li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>