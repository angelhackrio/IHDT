<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login {

    public function __construct() {
        $this->CI = & get_instance();

        if (!$this->CI->session->userdata('id_usuario')) {

            $uri_atual = uri_string();


            $paginas_publicas = array(
                'usuario/login', // Metodo de login do sistema
                'autenticacao', // Pagina de login
                'api/sensor/set',
                'api/autenticacao_mobile/login',
                'api/prontuario_mobile/listar',
                'api/prontuario_mobile/getProntuario'
            );

            /*
             * Se nao achar a URI atual no array de paginas publicas e tambem nao for das URI com parametros adicionais
             * Entao o usuario nao pode visualizar aquela pagina sem estar logado.
             */
            if ((!in_array($uri_atual, $paginas_publicas)) && strpos($uri_atual, "api") < 0) {
                if (uri_string() !== '') {
                    $this->CI->session->set_flashdata('msg', 'Acesso restrito');
                    $this->CI->session->set_flashdata('type', 'warning');
                    $this->CI->session->set_flashdata('title', 'Acesso restrito');
                }
                redirect(base_url() . "autenticacao");
            }
        }
    }

}

?>