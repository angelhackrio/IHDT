<?php

class Sensor_model extends CI_Model {
 
    function setDados($sensores){
        $sql = "INSERT INTO sensor (temperatura, umidade, temperatura_externa, umidade_externa, id_prontuario, id_equipamento, acelerometro_x, acelerometro_y, acelerometro_z) "
                . "VALUES ("
                . $this->db->escape($sensores['temperatura']).", "
                . $this->db->escape($sensores['umidade']).","
                . $this->db->escape($sensores['temperatura_externa']).", "
                . $this->db->escape($sensores['umidade_externa']).","
                . $this->db->escape($sensores['id_prontuario']).", "
                . $this->db->escape($sensores['id_equipamento']) .", "
                . $this->db->escape($sensores['acelerometro_x']).", "
                . $this->db->escape($sensores['acelerometro_y']).", "
                . $this->db->escape($sensores['acelerometro_z'])
                .")";
        
        $query = $this->db->query($sql);

        if ($query) {
            return true;
        } else {
            return false;
        }
    }
    
    function getUltimosDados($idProntuario){
        $sql = "SELECT s.id, s.temperatura, s.temperatura_externa, s.datahora, s.id_prontuario, s.id_equipamento, s.umidade, s.umidade_externa, s.acelerometro_x, s.acelerometro_y, s.acelerometro_z FROM sensor s "
                . "WHERE s.id_prontuario = ".$this->db->escape($idProntuario).""
                . "AND TO_CHAR(s.datahora, 'YYYY-MM-DD HH24:MI:SS') >= TO_CHAR((CURRENT_TIMESTAMP - INTERVAL '24 HOUR'), 'YYYY-MM-DD HH24:MI:SS') "
                . "ORDER BY s.id DESC LIMIT 24";
        
        $query = $this->db->query($sql);

        if ($query) {
            return $query->result();
        } else {
            return false;
        }
    }
}