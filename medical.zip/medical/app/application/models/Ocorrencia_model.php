<?php

class Ocorrencia_model extends CI_Model {

    function resolver($idOcorrencia) {
        $sql = "UPDATE ocorrencia SET atendido = true WHERE id = " . $this->db->escape($idOcorrencia);

        $query = $this->db->query($sql);

        if ($query) {
            return true;
        } else {
            return false;
        }
    }

    function setOcorrencia($idProntuario, $idPatologia) {
        $sql = "INSERT INTO ocorrencia (id_prontuario, id_patologia) "
                . "VALUES (" . $this->db->escape($idProntuario) . ", "
                . $this->db->escape($idPatologia) . ")";
        
        $query = $this->db->query($sql);

        if ($query) {
            return true;
        } else {
            return false;
        }
    }

}
