<?php

class Equipamento_model extends CI_Model {
 
    function getEquipamento($key){
        $sql = "SELECT e.id, e.key FROM equipamento e WHERE e.status = true AND e.key = ".$this->db->escape($key);
        
        $query = $this->db->query($sql);

        if ($query) {
            return $query->result();
        } else {
            return false;
        }
    }
}