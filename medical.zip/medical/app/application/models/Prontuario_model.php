<?php

class Prontuario_model extends CI_Model {

    function getProntuario($id) {
        $sql = "SELECT p.id, p.datahora, p.id_paciente, p.alta, p.dispensado, pa.nome, pa.sobrenome, pa.data_nascimento, p.diagnostico "
        //$sql = "SELECT p.id, p.id_paciente, p.alta, p.dispensado, pa.nome, pa.sobrenome, p.diagnostico "
                . "FROM prontuario p "
                . "INNER JOIN paciente pa ON pa.id = p.id_paciente "
                . "WHERE p.id = " . $this->db->escape($id);

        $query = $this->db->query($sql);

        if ($query) {
            return $query->result();
        } else {
            return false;
        }
    }

    function listProntuariosDashboard() {
        $sql = "SELECT p.id, p.datahora, p.id_paciente, p.alta, p.dispensado, p.diagnostico, p.datahora, pa.nome, pa.data_nascimento, oc.id AS id_ocorrencia, oc.id_patologia, oc.id_receita, pt.nome AS patologia "
                . "FROM prontuario p "
                . "INNER JOIN paciente pa ON pa.id = p.id_paciente "
                . "LEFT JOIN ocorrencia oc ON oc.id = (SELECT MAX(oc2.id) FROM ocorrencia oc2 WHERE oc2.id_prontuario = p.id) AND oc.atendido = false "
                . "LEFT JOIN patologia pt ON pt.id = oc.id_patologia "
                . "WHERE p.alta = false AND p.dispensado = false "
                . "ORDER BY oc.id";

//        $sql = "SELECT p.id, p.datahora, p.id_paciente, p.alta, p.dispensado, p.diagnostico, p.datahora, pa.nome, pa.data_nascimento, "
//                . "FROM prontuario p "
//                . "INNER JOIN paciente pa ON pa.id = p.id_paciente "
//                //. "LEFT JOIN ocorrencia oc ON oc.id = (SELECT MAX(oc2.id) FROM ocorrencia oc2 WHERE oc2.id_prontuario = p.id) AND oc.atendido = false "
//                . "WHERE p.alta = false AND p.dispensado = false ";
//                //. "ORDER BY oc.id";
//        
        $query = $this->db->query($sql);

        if ($query) {
            return $query->result();
        } else {
            return false;
        }
    }

    function listProntuariosMedico($idUsuario) {
//        $sql = "SELECT p.id, p.datahora, p.id_paciente, p.alta, p.dispensado, p.diagnostico, pa.nome, pa.data_nascimento "
//                . "FROM prontuario p "
//                . "INNER JOIN paciente pa ON pa.id = p.id_paciente "
//                . "INNER JOIN usuario_prontuario up ON up.id = (SELECT MAX(up2.id) FROM usuario_prontuario up2 WHERE up2.id_prontuario = p.id) "
//                . "WHERE up.id_usuario = " . $this->db->escape($idUsuario);
        
        $sql = "SELECT pa.nome, p.id "
                . "FROM prontuario p "
                . "INNER JOIN paciente pa ON pa.id = p.id_paciente "
                . "INNER JOIN usuario_prontuario up ON up.id = (SELECT MAX(up2.id) FROM usuario_prontuario up2 WHERE up2.id_prontuario = p.id) "
                . "WHERE up.id_usuario = " . $this->db->escape($idUsuario);

        $query = $this->db->query($sql);

        if ($query) {
            return $query->result();
        } else {
            return false;
        }
    }

}
