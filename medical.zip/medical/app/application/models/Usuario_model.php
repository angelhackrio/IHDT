<?php

class Usuario_model extends CI_Model {

    function getUsuarioEnfermeiraLogin($email, $senha) {
        $sql = "SELECT u.id, u.nome, u.email FROM usuario u "
                . "INNER JOIN enfermeira e ON e.id_usuario = u.id "
                . "WHERE u.status = true "
                . "AND email = " . $this->db->escape($email) . " AND senha = MD5(" . $this->db->escape($senha) . ")";

        $query = $this->db->query($sql);

        if ($query) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    function getUsuarioMedicoLogin($email, $senha) {
        $sql = "SELECT u.id, u.nome, u.email FROM usuario u "
                . "INNER JOIN medico m ON m.id_usuario = u.id "
                . "WHERE u.status = true "
                . "AND email = " . $this->db->escape($email) . " AND senha = MD5(" . $this->db->escape($senha).")";

        $query = $this->db->query($sql);

        if ($query) {
            return $query->result();
        } else {
            return false;
        }
    }

}
