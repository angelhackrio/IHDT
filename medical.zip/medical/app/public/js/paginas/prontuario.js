var valoresGraficoTemperatura = [];
var valoresGraficoTemperaturaExterna = [];

var valoresGraficoUmidade = [];
var valoresGraficoUmidadeExterna = [];

var valoresGraficoAcelerometrox = [];
var valoresGraficoAcelerometroy = [];
var valoresGraficoAcelerometroz = [];

var chartGraficoTemperatura = null;
var chartGraficoUmidade = null;
var chartGraficoAcelerometro = null;

$(document).ready(function () {
    chartGraficoTemperatura = new CanvasJS.Chart("graficoTemperatura",
            {
                zoomEnabled: true,
                exportEnabled: true,
                theme: "theme1",
                axisY: {
                    labelFontColor: "dimGrey",
                    title: "Temperatura",
                    titleFontSize: 20,
                    labelFontSize: 12
                },
                axisX: {
                    labelAngle: -30,
                    title: "Data",
                    valueFormatString: "DD/MM/YYYY",
                    titleFontSize: 20,
                    labelFontSize: 12
                },
                title: {
                    text: "Temperatura"
                },
                data: [
                    {
                        toolTipContent: "{dataFormatada} : {y}",
                        type: "line",
                        dataPoints: valoresGraficoTemperatura
                    },
                    {
                        toolTipContent: "{dataFormatada} : {y}",
                        type: "line",
                        dataPoints: valoresGraficoTemperaturaExterna
                    }
                ]
            });
    chartGraficoUmidade = new CanvasJS.Chart("graficoUmidade",
            {
                zoomEnabled: true,
                exportEnabled: true,
                theme: "theme1",
                axisY: {
                    labelFontColor: "dimGrey",
                    title: "Umidade",
                    titleFontSize: 20,
                    labelFontSize: 12
                },
                axisX: {
                    labelAngle: -30,
                    title: "Data",
                    valueFormatString: "DD/MM/YYYY",
                    titleFontSize: 20,
                    labelFontSize: 12
                },
                title: {
                    text: "Umidade"
                },
                data: [
                    {
                        toolTipContent: "{dataFormatada} : {y}",
                        type: "line",
                        dataPoints: valoresGraficoUmidade
                    },
                    {
                        toolTipContent: "{dataFormatada} : {y}",
                        type: "line",
                        dataPoints: valoresGraficoUmidadeExterna
                    }
                ]
            });
            chartGraficoAcelerometro = new CanvasJS.Chart("graficoAcelerometro",
            {
                zoomEnabled: true,
                exportEnabled: true,
                theme: "theme1",
                axisY: {
                    labelFontColor: "dimGrey",
                    title: "Acelerometro",
                    titleFontSize: 20,
                    labelFontSize: 12
                },
                axisX: {
                    labelAngle: -30,
                    title: "Data",
                    valueFormatString: "DD/MM/YYYY",
                    titleFontSize: 20,
                    labelFontSize: 12
                },
                title: {
                    text: "Acelerometro"
                },
                data: [
                    {
                        toolTipContent: "{dataFormatada} : {y}",
                        type: "line",
                        dataPoints: valoresGraficoAcelerometrox
                    },
                    {
                        toolTipContent: "{dataFormatada} : {y}",
                        type: "line",
                        dataPoints: valoresGraficoAcelerometroy
                    },
                    {
                        toolTipContent: "{dataFormatada} : {y}",
                        type: "line",
                        dataPoints: valoresGraficoAcelerometroz
                    }
                ]
            });

    updateChart('graficoTemperatura');
    updateChart('graficoUmidade');
    updateChart('graficoAcelerometro');

    function updateChart(grafico) {

        $.ajax({
            type: "POST",
            async: true,
            url: base_url + 'prontuario/dadosGraficos/' + $("#hdId").val(),
            dataType: "JSON",
            success: function (data) {
                var stack = [];
                var chart = null;
                switch (grafico) {
                    case 'graficoTemperatura':
                        {
                            stackTemp = valoresGraficoTemperatura;
                            stackTempEx = valoresGraficoTemperaturaExterna;
                            chart = chartGraficoTemperatura;
                        }
                        break;
                    case 'graficoUmidade':
                        {
                            stackUmi = valoresGraficoUmidade;
                            stackUmiEx = valoresGraficoUmidadeExterna;
                            chart = chartGraficoUmidade;
                        }
                        break;
                        case 'graficoAcelerometro':
                        {
                            stackX = valoresGraficoAcelerometrox;
                            stackY = valoresGraficoAcelerometroy;
                            stackZ = valoresGraficoAcelerometroz;
                            chart = chartGraficoAcelerometro;
                        }
                        break;
                }

                while (stack.length > 0) {
                    if (grafico === 'graficoTemperatura') {
                        stackTemp.pop();
                        stackTempEx.pop();
                    } else if (grafico === 'graficoUmidade'){
                        stackUmi.pop();
                        stackUmiEx.pop();
                    } else {
                        stackX.pop();
                        stackY.pop();
                        stackZ.pop();
                    }
                }
                data = data.dados;

                for (i = 0; i < data.length; i++) {
                    if (grafico === 'graficoTemperatura') {
                        stackTemp.push({x: new Date((data[i].datahora).replace(" ", "T")), y: parseFloat(data[i].temperatura), dataFormatada: data[i].dataFormatada});
                        stackTempEx.push({x: new Date((data[i].datahora).replace(" ", "T")), y: parseFloat(data[i].temperatura_externa), dataFormatada: data[i].dataFormatada});
                    } else if (grafico === 'graficoUmidade'){
                        stackUmi.push({x: new Date((data[i].datahora).replace(" ", "T")), y: parseFloat(data[i].umidade), dataFormatada: data[i].dataFormatada});
                        stackUmiEx.push({x: new Date((data[i].datahora).replace(" ", "T")), y: parseFloat(data[i].umidade_externa), dataFormatada: data[i].dataFormatada});
                    } else {
                        stackX.push({x: new Date((data[i].datahora).replace(" ", "T")), y: parseFloat(data[i].acelerometro_x), dataFormatada: data[i].dataFormatada});
                        stackY.push({x: new Date((data[i].datahora).replace(" ", "T")), y: parseFloat(data[i].acelerometro_y), dataFormatada: data[i].dataFormatada});
                        stackZ.push({x: new Date((data[i].datahora).replace(" ", "T")), y: parseFloat(data[i].acelerometro_z), dataFormatada: data[i].dataFormatada});
                    }
                }

                chart.render();
            },
            error: function (data) {
                console.log(data);
            }
        });
    }
});