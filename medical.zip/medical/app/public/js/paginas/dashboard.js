$(document).ready(function () {
    var prontuarioTemplate = '<div class="col-md-3"><div class="panel panel-primary"><div class="panel-heading"><h3 class="panel-title">Internado</h3></div><div class="panel-body"><strong>Nome:</strong> <span class="nome">José Maria</span><br /><strong>Data nascimento:</strong> <span class="data_nascimento">25 anos</span><br /><strong>Data de internação:</strong> <span class="data_internacao">01/06/2016 10:02</span><br /><strong>Diagnóstico: </strong><span class="diagnostico"></span></div><div class="panel-footer"><a href="" class="btn btn-primary">Detalhes</a></div></div></div>';
    setInterval(function () {
        atualizar();
    }, 3000);

    atualizar();

    function atualizar() {

        $.ajax({
            type: 'POST',
            url: base_url + 'dashboard/atualizarDashboard',
            dataType: 'JSON',
            success: function (data) {
                if (data.sucesso === "false") {
                    new $.Zebra_Dialog(data.msg, {title: data.title, type: data.type});
                } else {
                    $(".prontuarios").html('');
                    $.each(data.prontuarios, function (index, value) {

                        var $prontuario = $(prontuarioTemplate);
                        $(".nome", $prontuario).html(value.nome);
                        $(".data_nascimento", $prontuario).html(value.data_nascimento);
                        $(".data_internacao", $prontuario).html(value.datahora);
                        $(".diagnostico", $prontuario).html(value.diagnostico);
                        $(".btn", $prontuario).attr("href", base_url + 'prontuario/ver/' + value.id);
                        if (value.id_patologia > 0) {
                            $(".panel", $prontuario).removeClass('panel-primary').addClass('panel-danger');
                            $(".panel", $prontuario).addClass('frenetic-blink');
                            //$(".btn", $prontuario).removeClass('btn-primary').addClass('btn-danger');
                            botaoResolver = "<a class='btn btn-danger pull-right' href='"+base_url+'ocorrencia/resolver/'+value.id_ocorrencia+"'>Resolver</a>";
                            $botaoResolver = $(botaoResolver);
                            $(".panel-title", $prontuario).html(value.patologia);
                            $(".panel-footer", $prontuario).append($botaoResolver);
                        } else if (value.id_receita > 0) {
                            $(".panel", $prontuario).removeClass('panel-primary').addClass('panel-warning');
                            //$(".btn", $prontuario).removeClass('btn-primary').addClass('btn-warning');
                            botaoResolver = "<a class='btn btn-danger pull-right' href='"+base_url+'ocorrencia/resolver/'+value.id_ocorrencia+"'>Resolver</a>";
                            $botaoResolver = $(botaoResolver);
                            $(".panel-footer", $prontuario).append($botaoResolver);
                        }
                        $(".prontuarios").append($prontuario);
                    });
                }
            },
            error: function (data) {
                console.log(data);
                new $.Zebra_Dialog('Ocorreu um erro, por favor tente mais tarde.', {'title': 'Erro!', 'type': 'error'});
            }
        });
    }
});