//WEBSERVICE_URL = 'http://localhost/reconditec/fontes/8PAINEL/webservice/';
WEBSERVICE_URL = 'http://50.22.205.177/admin/webservice/';