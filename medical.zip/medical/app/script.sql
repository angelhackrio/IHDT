﻿CREATE TABLE usuario(
id SERIAL PRIMARY KEY NOT NULL,
nome VARCHAR(100) NOT NULL,
email VARCHAR(100) NOT NULL,
senha VARCHAR(32) NOT NULL,
status BOOLEAN DEFAULT TRUE);

CREATE TABLE medico(
id SERIAL PRIMARY KEY NOT NULL,
especialidade VARCHAR(100) NOT NULL,
id_usuario INTEGER NOT NULL,
CONSTRAINT fk_medico_with_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id));

CREATE TABLE enfermeira(
id SERIAL PRIMARY KEY NOT NULL,
id_usuario INTEGER NOT NULL,
CONSTRAINT fk_enfermeira_with_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id));

CREATE TABLE patologia(
id SERIAL PRIMARY KEY NOT NULL,
nome VARCHAR(100) NOT NULL);

CREATE TABLE medicacao(
id SERIAL PRIMARY KEY NOT NULL,
nome VARCHAR(200) NOT NULL,
composicao TEXT NOT NULL);

CREATE TABLE paciente(
id SERIAL PRIMARY KEY NOT NULL,
nome VARCHAR(100) NOT NULL,
sobrenome VARCHAR(100) NOT NULL,
data_nascimento TIMESTAMP WITHOUT TIME ZONE NULL);

-- DEPENDENTES DO PACIENTE

CREATE TABLE prontuario(
id SERIAL PRIMARY KEY NOT NULL,
id_paciente INTEGER NOT NULL,
datahora TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
diagnostico TEXT NULL,
alta BOOLEAN DEFAULT FALSE,
dispensado BOOLEAN DEFAULT FALSE,
CONSTRAINT fk_prontuario_with_paciente FOREIGN KEY(id_paciente) REFERENCES paciente (id));


-- TABELA DE RELACIONAMENTO MULTIPLO ENTRE O USUARIO (MEDICO) E O PRONTURARIO,
-- INDICANDO QUE O PACIENTE PODE SOFRER ALTERACAO DO MEDICO RESPONSAVEL PELO PRONTUARIO
CREATE TABLE usuario_prontuario(
id SERIAL PRIMARY KEY NOT NULL, 
id_usuario INTEGER NOT NULL,
id_prontuario INTEGER NOT NULL,
CONSTRAINT fk_usuario_prontuario_with_prontuario FOREIGN KEY (id_prontuario) REFERENCES prontuario (id),
CONSTRAINT fk_usuario_prontuario_with_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id));


CREATE TABLE equipamento(
id SERIAL PRIMARY KEY NOT NULL,
key VARCHAR(32) NOT NULL,
status BOOLEAN DEFAULT TRUE);

CREATE TABLE sensor(
id SERIAL PRIMARY KEY NOT NULL,
datahora TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
id_prontuario INTEGER NOT NULL,
id_equipamento INTEGER NOT NULL,
umidade FLOAT NULL,
temperatura FLOAT NULL,
temperatura_externa FLOAT NULL,
umidade_externa FLOAT NULL,
acelerometro_x FLOAT NULL,
acelerometro_y FLOAT NULL,
acelerometro_z FLOAT NULL,
CONSTRAINT fk_usuario_sensor_with_equipamento FOREIGN KEY (id_equipamento) REFERENCES equipamento(id),
CONSTRAINT fk_usuario_sensor_with_prontuario FOREIGN KEY (id_prontuario) REFERENCES prontuario(id));

CREATE TABLE receita(
id SERIAL PRIMARY KEY NOT NULL,
id_medicacao INTEGER NOT NULL,
id_prontuario INTEGER NOT NULL,
id_usuario INTEGER NOT NULL,
datahora TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
CONSTRAINT fk_receita_with_prontuario FOREIGN KEY (id_prontuario) REFERENCES prontuario(id),
CONSTRAINT fk_receita_with_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id),
CONSTRAINT fk_receita_with_medicacao FOREIGN KEY (id_medicacao) REFERENCES medicacao(id));

CREATE TABLE ocorrencia(
id SERIAL PRIMARY KEY NOT NULL,
id_receita INTEGER NULL,
id_prontuario INTEGER NOT NULL,
id_patologia INTEGER NOT NULL,
datahora TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
atendido BOOLEAN DEFAULT FALSE,
CONSTRAINT fk_ocorrencia_with_receita FOREIGN KEY (id_receita) REFERENCES receita(id),
CONSTRAINT fk_ocorrencia_with_prontuario FOREIGN KEY (id_prontuario) REFERENCES prontuario(id),
CONSTRAINT fk_ocorrencia_with_patologia FOREIGN KEY (id_patologia) REFERENCES patologia (id));

--DADOS
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('Gustavo', 'Quirino', '1992-01-13');
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('José', 'Antonio', '1991-02-23');
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('Maria', 'Júlia', '1951-03-22');
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('Cláudia', 'Silva', '1971-08-12');
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('Francisco', 'Moreira', '1997-07-11');
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('Everton', 'Pereira', '1997-11-23');
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('Laura', 'Antonia', '1982-11-21');
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('Mariana', 'Assis', '1986-10-13');
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('Claudete', 'Moreira', '1982-09-27');
INSERT INTO paciente (nome, sobrenome, data_nascimento) VALUES ('Lucas', 'Wood', '1985-10-05');

INSERT INTO usuario (nome, senha, email) VALUES ('Dr. Michel', MD5('123'), 'michel@email.com');
INSERT INTO usuario (nome, senha, email) VALUES ('Srta. Célia', MD5('123'), 'celia@email.com');
INSERT INTO medico (especialidade, id_usuario) VALUES ('Cirurgiao', 1);
INSERT INTO enfermeira (id_usuario) VALUES (2);

INSERT INTO prontuario (id_paciente, diagnostico) VALUES (1, 'virose');
INSERT INTO prontuario (id_paciente, diagnostico) VALUES (2, 'virose');
INSERT INTO prontuario (id_paciente, diagnostico) VALUES (3, 'virose');
INSERT INTO prontuario (id_paciente, diagnostico) VALUES (4, 'virose');
INSERT INTO prontuario (id_paciente, diagnostico) VALUES (5, 'virose');
INSERT INTO prontuario (id_paciente, diagnostico) VALUES (6, 'virose');
INSERT INTO prontuario (id_paciente, diagnostico) VALUES (7, 'virose');
INSERT INTO prontuario (id_paciente, diagnostico) VALUES (8, 'virose');
INSERT INTO prontuario (id_paciente, diagnostico) VALUES (9, 'virose');
INSERT INTO prontuario (id_paciente, diagnostico) VALUES (10, 'virose');

INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (1,1);
INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (2,1);
INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (3,1);
INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (4,1);
INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (5,1);
INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (6,1);
INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (7,1);
INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (8,1);
INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (9,1);
INSERT INTO usuario_prontuario (id_prontuario, id_usuario) VALUES (10,1);

INSERT INTO equipamento (key) VALUES (MD5('123'));

INSERT INTO patologia (nome) VALUES ('Convulsao');
INSERT INTO patologia (nome) VALUES ('Hipertemia');
INSERT INTO patologia (nome) VALUES ('Vomito');
INSERT INTO patologia (nome) VALUES ('Hipotermia');
INSERT INTO ocorrencia (id_patologia, id_prontuario) VALUES (1, 10);


SELECT * FROM equipamento;
select * from usuario;
select * from paciente;
select * from usuario_prontuario;
select * from sensor;
select * from prontuario;
select md5('123');
select * from patologia;


update prontuario set alta = false where id_paciente = 5;
select * from sensor;
select * from paciente;

